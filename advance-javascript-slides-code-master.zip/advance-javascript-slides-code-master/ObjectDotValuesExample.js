// Object.values

let obj = {
    fname: "Aamir",
    lname: "Pinger",
    degrees: 2,
}

let newArray = Object.values(obj)

console.log(newArray)   // RESULT: ["Aamir", "Pinger", 2]
