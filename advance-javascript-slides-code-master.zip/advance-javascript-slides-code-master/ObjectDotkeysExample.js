//Object.keys

let obj = {
    fname: "Aamir",
    lname: "Pinger",
    degrees: 2,
}

let newArray = Object.keys(obj)

console.log(newArray)  //RESULT : ["fname", "lname", "degrees"]


