//VARIABLE HOISTING
// Try any part one at a time

var myname;         // Declare Variable
myname = 'Aamir';   // Initialize variable
console.log(myname) // result: Aamir



/*********************************** */

// var myname;          // Declare Variable
// console.log(myname)  // result: Undefined
// myname = 'Aamir';    // Initialize variable



/*********************************** */

// console.log(myname)  // result: Undefined
// myname = 'Aamir';    // Initialize variable
// var myname;          // Declare Variable



/*********************************** */

// console.log(myname)  // result: ERROR: myname is not defined
//myname = 'Aamir';     // Initialize variable

