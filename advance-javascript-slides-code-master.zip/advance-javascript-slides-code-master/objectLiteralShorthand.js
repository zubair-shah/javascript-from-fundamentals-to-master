//OBJECT LITERAL SHORTHAND


const firstName = "Aamir"
let lastName = "Pinger"
var degrees = 2

/************************************************** */
// Try any part one at a time


let myObject = {
    firstName: firstName,
    lastName: lastName,
    degrees: degrees
}
console.log(myObject)  //RESULT: {firstName: "Aamir", lastName: "Pinger", degrees: 2}





/************************************************** */

// const firstName = "Aamir"
// let lastName = "Pinger"
// var degrees = 2

// let myObject = {
//     firstName,
//     lastName,
//     degrees
// }
// console.log(myObject)  //RESULT: {firstName: "Aamir", lastName: "Pinger", degrees: 2}
