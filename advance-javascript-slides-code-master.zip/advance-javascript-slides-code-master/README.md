## All the code from the slides of Advance Javascript
