// SET

/************************************************** */
// Try any part one at a time

const newSet = new Set(["Aamir", "Pinger", "Aamir"]);

console.log(newSet);    // Result: Set(2) {"Aamir", "Pinger"}




/************************************************** */



// const newSet = new Set();

// console.log(newSet);

// newSet.add("aamir")
// newSet.add("pinger")
// newSet.add("qassim")
// newSet.delete("qassim")
// newSet.add("aamir")

// console.log(newSet);    // Result: Set(2) {"Aamir", "Pinger"}



/************************************************** */


// const newSet = new Set();

// console.log(newSet);

// newSet.add("aamir")
// newSet.add("pinger")
// newSet.add("qassim")
// newSet.delete("qassim")
// newSet.add("aamir")

// console.log(newSet)

// for (i of newSet) {
//     console.log(i)
// }

// Result:
// Set(2) {"Aamir", "Pinger"}
// Aamir
// Pinger
